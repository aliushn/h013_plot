#ifndef JWIMU_H
#define JWIMU_H

#include <QObject>

class jwIMU
{
    Q_OBJECT
public:
    jwIMU();
};

#endif // JWIMU_H
