#ifndef JWMQTT_H
#define JWMQTT_H

#include <QObject>
#include <QWidget>
//#include <QtMqtt/QtMqtt>

class jwmqtt
{
public:
    jwmqtt();
};

#endif // JWMQTT_H
