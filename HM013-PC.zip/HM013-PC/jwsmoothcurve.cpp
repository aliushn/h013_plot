#include "jwsmoothcurve.h"

jwSmoothCurve::jwSmoothCurve()
{

}
