#ifndef MAINTABLE_H
#define MAINTABLE_H

#include <QObject>
#include <QWidget>
#include <QTableWidget>

class mainTable
{
public:
    mainTable();
    QTableWidget m_tablewight;
};

#endif // MAINTABLE_H
