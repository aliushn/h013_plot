#ifndef GENERICCALLBACK_H
#define GENERICCALLBACK_H

/*
namespace hjw
{
/////////////////////////////////////////////////////////////////
template <class T1=void, class T2=void, class T3=void>
class GenericCallback
{
public:

    virtual ~GenericCallback()
    {

    }

    virtual void excute(T1 val1,T2 val2,T3 val3)=0;

    virtual bool isValid() const =0;

};

/////////////////////////////////////////////////////////////////












}
*/
#endif // GENERICCALLBACK_H
